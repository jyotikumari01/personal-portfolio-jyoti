# Jyoti Kumari — Portfolio

A simple, responsive, static portfolio website.

## Run locally

Open `index.html` in a browser.

## Deploy with GitHub Pages

1. Create a public GitHub repository (for example, `jyoti-portfolio`).
2. Upload `index.html`, `README.md`, and `.nojekyll` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select **main** and **/(root)**, then save.
6. GitHub Pages will publish the site at `https://<your-github-username>.github.io/jyoti-portfolio/`.

For a user site URL (`https://<your-github-username>.github.io/`), name the repository exactly `<your-github-username>.github.io`.

## Custom domain (optional)

After purchasing a domain, add it under **Settings → Pages → Custom domain** and configure the DNS records shown by GitHub. Enable **Enforce HTTPS** once DNS verification completes.
